console.log('check')

let s1=0, s2=0;
for(let n=1; n<100; n++){
    if(n%2===0){
        s1=s1+n;
    }
    else if(n%3===0){
        s2=s2+n;
    }
}
console.log(s1+s2);
// console.log(s1);
// console.log(s2);

// let sum=0;
// for(let i=1; i<100; i++){
//     if(i%3===0){
//         sum=sum+i;
//     }
// }
// console.log(sum);

